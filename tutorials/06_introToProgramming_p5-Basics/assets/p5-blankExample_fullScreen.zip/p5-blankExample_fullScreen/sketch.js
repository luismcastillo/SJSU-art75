
// declare variables here


// setup runs once
function setup() {
	// make canvas full screen
	createCanvas(windowWidth, windowHeight);

}

// draw loops and loops
function draw() {
	// adding clear() to the draw loop will clear each frame, erasing object trails
	// clear();
	ellipse(mouseX, mouseY, 100);
}


// write functions here
